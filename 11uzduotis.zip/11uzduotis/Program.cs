﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11uzduotis
{
    class Program
    {
        static void Main(string[] args)
        {
            string duom = "U3.txt";
            int M;
            int N;
            Cele[,] Pilis = Skaityti(out M, out N, duom);
            int kambariuSk = IeskotiKambariu(Pilis, M, N);
            Console.WriteLine(kambariuSk);
        }

        static Cele[,] Skaityti( out int M, out int N, string duom)
        {
            Cele[,] Pilis;
            using (StreamReader reader = new StreamReader(duom))
            {
                M = int.Parse(reader.ReadLine());
                N = int.Parse(reader.ReadLine());
                Pilis = new Cele [N, M];
                for (int i = 0; i < M; i++)
                {
                    string line = reader.ReadLine();
                    string[] values = line.Split(' ');

                    for (int j = 0; j < N; j++)
                    {
                        Cele cele = new Cele(int.Parse(values[j]));
                        Pilis[j, i] = cele;
                    }
                }
            }
            return Pilis;
        }

        static int IeskotiKambariu(Cele[,] Pilis, int M, int N)
        {
            int kambariuSk = 0;
            for (int i = 0; i <M; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if (!Pilis[j,i].Aplankyta)
                    {
                        Kambarys(Pilis, j, i);
                        kambariuSk++;
                    }
                }
            }
            return kambariuSk;
        }

        static void Kambarys(Cele[,] Pilis, int x, int y)
        {
            int sienos = Pilis[x,y].Sienos;
            Pilis[x,y].Aplankyta = true;
            if (sienos == 15)
            {
                return;
            }
            if (sienos < 8)
            {
                if (!Pilis[x,y+1].Aplankyta)
                {
                    Kambarys(Pilis, x, y + 1);
                }
            }
            else
            {
                sienos -= 8;
            }
            if (sienos < 4)
            {
                if (!Pilis[x+1,y].Aplankyta)
                {
                    Kambarys(Pilis, x + 1, y);
                }
            }
            else
            {
                sienos -= 4;
            }
            if (sienos < 2)
            {
                if (!Pilis[x,y-1].Aplankyta)
                {
                    Kambarys(Pilis, x, y - 1);
                }
            }
            else
            {
                sienos -= 2;
            }
            if (sienos < 1)
            {
                if (!Pilis[x-1,y].Aplankyta)
                {
                    Kambarys(Pilis, x - 1, y);
                }
            }
            return;

        }
    }
}
