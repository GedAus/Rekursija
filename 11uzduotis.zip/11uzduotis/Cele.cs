﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11uzduotis
{
    class Cele
    {
        public int Sienos { get; set; }
        public bool Aplankyta;

        public Cele(int sienos)
        {
            Sienos = sienos;
            Aplankyta = false;
        }

    }
}
